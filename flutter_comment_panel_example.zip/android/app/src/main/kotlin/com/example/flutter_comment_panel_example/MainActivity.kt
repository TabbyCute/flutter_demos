package com.example.flutter_comment_panel_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
