import 'package:flutter/cupertino.dart';

/// @author: pengboboer
/// @createDate: 2023/6/28
class CommentDetailModel extends ChangeNotifier{
  BuildContext? currentNavigatorContext;
}